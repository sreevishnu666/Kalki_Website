# Kalki Automation – Website

Static multi-page site (plain HTML/CSS/JS, no build step). Open `index.html` in a browser, or host the folder on any static host (GitHub Pages, Netlify, etc.).

| Page | File |
|---|---|
| Home | `index.html` |
| Air Flow Meter | `air-flow-meter.html` |
| Dew Point Sensor | `dew-point-sensor.html` |
| Dynamic Air Flow Meter | `dynamic-air-flow-meter.html` |
| Digital Pascal Meter | `digital-pascal-meter.html` |

- `images/` – logo, hero, product and brand images
- `brochures/` – downloadable PDF brochures

Fonts load from Google Fonts (Roboto).
